function adicionarAoCarrinho(item) {
    alert(item + " adicionado ao carrinho!");
}

function mostrarAlerta() {
    alert("Item adicionado ao carrinho!");
}

function redirecionarParaCarrinho() {
    window.location.href = "carrinho.html";
}